
This repository is for a final group project for the course: Web Analytics

Project

Your task is to build a regression model that can accurately predict the gap between the average audience rating and the average critic rating for a movie.

You will train your model on data collected from rottentomatoes. You can collect as much data as you want.

Your model will be tested on a separate dataset that you will not have access to. This testing set will also be collected from rottentomatoes.

Your model can utilize any features that you think can explain the rating gap.

This is a team a project.

# Movie-Prediction-Rottentomatoes
This script predicts the Gap between Critics rating and Audience Rating based on various features like Runtime, Rating, Genre, Cast, Director, Producer


